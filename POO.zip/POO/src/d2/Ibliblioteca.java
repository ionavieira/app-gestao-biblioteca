
package d2;

public interface Ibliblioteca {
    void cadastrarUsuario();
    void cadastrarPublicacao();
    void cadastrarEmprestico();
    void cadastrarDevolucao();
    void gerarCodigo();
    void listarUsuario();
    void listarPublicacao();
    void listarEmprestimo();
    void listarDevolucao();
    void pesquisarPublicacao();
    
}
