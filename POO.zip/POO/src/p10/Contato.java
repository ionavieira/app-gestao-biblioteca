package p10;

public class Contato {
    private int id;
    private String nome;
    private String telefone;
    
    
}
