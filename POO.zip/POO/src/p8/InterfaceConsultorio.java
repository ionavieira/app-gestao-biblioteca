
package p8;


public interface InterfaceConsultorio {
    void consulta(int cpf);
    void insere();
    void altera();
    double calcularValores();
}
